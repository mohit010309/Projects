AP Project Group 3 

Team members :

19ucc023 - Mohit Akhouri
19ucc026 - Divyansh Rastogi
19ucc043 - Aditya Pandey
19ucc119 - Abhinav Raj Upman

Some important points regarding project :

(1) The connector jar file should be added to "Java project" using :
      JRE System Library > Build Path > Configure build path > Libraries > Add External JARs

(2) For connecting to database used in the project , enter root password of MySql
